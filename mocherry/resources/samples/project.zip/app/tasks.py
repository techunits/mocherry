import celery
from celery import task

@task
def sample_task(self):
    print("This is sample task response!!!")

