import os
from celery import Celery

# setup config data
BASEPATH = os.getcwd()
default_app_name = 'app'
os.environ.setdefault('MOCHERRY_SETTINGS_PATH', os.path.join(BASEPATH, default_app_name, 'config', 'settings.json'))    
from mocherry.settings import CONFIG

# get celery config from project settings
BROKER_URL = CONFIG.get('celery').get('broker')

app = Celery(CONFIG.get('name'), 
                broker=BROKER_URL)

# get list of installed app tasks
installed_apps = CONFIG.get('server').get('apps')
app.autodiscover_tasks(lambda: installed_apps)

